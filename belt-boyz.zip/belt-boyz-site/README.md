# Belt Boyz — 4-layer parallax website starter

A standalone responsive website. No build step, framework, database, or paid dependency.

## Start
Open `index.html` in a browser, or run `python3 -m http.server 8000` inside this folder and visit http://localhost:8000.

## Sections
1. Hero/title with animated orbs, depth parallax and particles.
2. Character carousel; click each card for an individual story modal, main video, latest video links, bio and social links.
3. Hot Now carousel for featured videos, products and upcoming drops.
4. Future section with AI Universe, Products and Coming Soon detail popups.

## Add your actual content
Edit `data.js`:
- `characters`: change demo names, role, bio, story, and `video` URL. Add `posts` as `{title, url}` and `socials` as `{platform, url}`.
- `hot`: update featured cards and video URLs.
- `extras`: update future section detail popups.

## Add images later
The cards intentionally use gradient art placeholders. To add images, put them in `assets/` and extend the card markup in `app.js` to include `<img src="assets/filename.jpg" alt="...">`; style it using `object-fit: cover`. Character artwork and background images are not included in this starter.

## Notes
- Modal videos use native HTML5 `<video>` and work with direct video file URLs such as `.mp4`. YouTube/TikTok URLs need a provider-specific embed component.
- Social links are only rendered when populated.
- No backend, account system, commerce checkout, or live feed is included; those require future integration.
- The site uses Google Fonts when online; fallback fonts work offline.
- Motion is reduced automatically for visitors with reduced-motion enabled.
- No changes have been made to 1Muslim production.
